import { createClient } from '@supabase/supabase-js';

// Supabase configuration for project: ehvyyaelxvksbvgdocmg
export const SUPABASE_URL =
  ((import.meta as any).env?.VITE_SUPABASE_URL as string) ||
  'https://ehvyyaelxvksbvgdocmg.supabase.co';
export const SUPABASE_ANON_KEY =
  ((import.meta as any).env?.VITE_SUPABASE_ANON_KEY as string) ||
  'sb_publishable_UchZKolZ04Afw6DIvv_htA_awQveJhV';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export const SUPABASE_PROJECT_ID = 'ehvyyaelxvksbvgdocmg';
